"""Team / enterprise endpoints (Part 5.8).

Teams let organisations share templates and manage members with roles. Every
route is authenticated; mutating routes enforce role checks via
``app.services.team.team_service``. Member add/remove and template delete are
recorded to a per-team audit log that owners/admins can export.
"""

import json
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps.auth import get_current_user
from app.core.exceptions import AuthorizationError, NotFoundError, ValidationError
from app.db.database import get_db
from app.models.team import (
    SharedTemplate,
    Team,
    TeamAuditLog,
    TeamMember,
    TeamRole,
)
from app.models.user import User
from app.schemas.team import (
    AuditEntry,
    AuditExportResponse,
    MemberAddRequest,
    MemberResponse,
    TeamCreateRequest,
    TeamDetailResponse,
    TeamQuotaUpdateRequest,
    TeamResponse,
    TemplateCreateRequest,
    TemplateResponse,
)
from app.services.team import team_service

router = APIRouter()


# --- Teams ---------------------------------------------------------------

@router.post("", response_model=TeamResponse, status_code=201)
async def create_team(
    request: TeamCreateRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a team; the creator becomes its owner."""
    team = Team(name=request.name, owner_id=user.id)
    db.add(team)
    await db.flush()

    db.add(TeamMember(team_id=team.id, user_id=user.id, role=TeamRole.OWNER))
    await db.flush()
    await team_service.record_audit(
        db, team_id=team.id, actor_id=user.id, action="team.create", detail=request.name
    )

    return TeamResponse(
        id=str(team.id),
        name=team.name,
        owner_id=str(team.owner_id),
        role=TeamRole.OWNER,
        member_count=1,
        ai_daily_quota=team.ai_daily_quota,
        sso_required=team.sso_required,
        created_at=team.created_at,
    )


@router.get("", response_model=list[TeamResponse])
async def list_teams(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List all teams the authenticated user belongs to."""
    memberships = (
        await db.execute(select(TeamMember).where(TeamMember.user_id == user.id))
    ).scalars().all()

    out: list[TeamResponse] = []
    for m in memberships:
        team = await team_service.get_team(db, m.team_id)
        if team is None:
            continue
        out.append(
            TeamResponse(
                id=str(team.id),
                name=team.name,
                owner_id=str(team.owner_id),
                role=m.role,
                member_count=await team_service.member_count(db, team.id),
                ai_daily_quota=team.ai_daily_quota,
                sso_required=team.sso_required,
                created_at=team.created_at,
            )
        )
    return out


@router.get("/{team_id}", response_model=TeamDetailResponse)
async def get_team_detail(
    team_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Team detail including its members (any member may view)."""
    membership = await team_service.require_member(db, team_id, user.id)
    team = await team_service.get_team(db, team_id)

    members = (
        await db.execute(select(TeamMember).where(TeamMember.team_id == team_id))
    ).scalars().all()

    member_models: list[MemberResponse] = []
    for m in members:
        u = (
            await db.execute(select(User).where(User.id == m.user_id))
        ).scalar_one_or_none()
        if u is None:
            continue
        member_models.append(
            MemberResponse(
                user_id=str(u.id),
                email=u.email,
                full_name=u.full_name,
                role=m.role,
                joined_at=m.created_at,
            )
        )

    return TeamDetailResponse(
        id=str(team.id),
        name=team.name,
        owner_id=str(team.owner_id),
        role=membership.role,
        members=member_models,
        ai_daily_quota=team.ai_daily_quota,
        sso_required=team.sso_required,
        created_at=team.created_at,
    )


@router.put("/{team_id}/quota", response_model=TeamResponse)
async def update_team_quota(
    team_id: uuid.UUID,
    request: TeamQuotaUpdateRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update per-team AI quota and SSO flag (owner/admin only) — E8.1 / E8.2."""
    await team_service.require_manager(db, team_id, user.id)
    team = await team_service.get_team(db, team_id)
    if team is None:
        raise NotFoundError("Team")

    if request.ai_daily_quota is not None:
        if request.ai_daily_quota < 1:
            raise ValidationError("ai_daily_quota must be >=1 or None")
        team.ai_daily_quota = request.ai_daily_quota
    # Allow explicit nullification: when client sends {"ai_daily_quota": null}
    # Pydantic will set None, but we need to distinguish between omitted and null.
    # For simplicity, we treat omitted as no change, and we add a separate query param
    # to clear via model_fields_set check.
    if "ai_daily_quota" in request.model_fields_set and request.ai_daily_quota is None:
        # If explicitly set to None, clear quota
        team.ai_daily_quota = None

    if request.sso_required is not None:
        team.sso_required = request.sso_required

    await db.flush()
    await team_service.record_audit(
        db,
        team_id=team_id,
        actor_id=user.id,
        action="team.quota.update",
        detail=f"quota={team.ai_daily_quota} sso={team.sso_required}",
    )

    return TeamResponse(
        id=str(team.id),
        name=team.name,
        owner_id=str(team.owner_id),
        role=(await team_service.get_membership(db, team_id, user.id)).role,
        member_count=await team_service.member_count(db, team.id),
        ai_daily_quota=team.ai_daily_quota,
        sso_required=team.sso_required,
        created_at=team.created_at,
    )


# --- Members -------------------------------------------------------------

@router.post("/{team_id}/members", response_model=MemberResponse, status_code=201)
async def add_member(
    team_id: uuid.UUID,
    request: MemberAddRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Add a member by email (owner/admin only). Owner role cannot be assigned."""
    await team_service.require_manager(db, team_id, user.id)

    role = request.role.strip().lower()
    if role not in {TeamRole.ADMIN, TeamRole.MEMBER}:
        raise ValidationError("role must be 'admin' or 'member'")

    target = (
        await db.execute(select(User).where(User.email == request.email))
    ).scalar_one_or_none()
    if target is None:
        raise NotFoundError("User")

    existing = await team_service.get_membership(db, team_id, target.id)
    if existing is not None:
        raise ValidationError("User is already a member of this team")

    # E5.3 / E8.2 — SSO enforcement: if team requires SSO, target must be verified (SSO)
    team_obj = await team_service.get_team(db, team_id)
    if team_obj and team_obj.sso_required:
        if not target.is_verified:
            raise AuthorizationError(
                "This team requires SSO — user must have logged in via Google/Apple/OIDC at least once (is_verified)"
            )

    member = TeamMember(team_id=team_id, user_id=target.id, role=role)
    db.add(member)
    await db.flush()
    await team_service.record_audit(
        db,
        team_id=team_id,
        actor_id=user.id,
        action="member.add",
        target=str(target.id),
        detail=f"{target.email} as {role}",
    )

    return MemberResponse(
        user_id=str(target.id),
        email=target.email,
        full_name=target.full_name,
        role=role,
        joined_at=member.created_at,
    )


@router.delete("/{team_id}/members/{member_user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def remove_member(
    team_id: uuid.UUID,
    member_user_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Remove a member (owner/admin only). The owner cannot be removed."""
    await team_service.require_manager(db, team_id, user.id)

    membership = await team_service.get_membership(db, team_id, member_user_id)
    if membership is None:
        raise NotFoundError("Member")
    if membership.role == TeamRole.OWNER:
        raise AuthorizationError("The team owner cannot be removed")

    await db.delete(membership)
    await team_service.record_audit(
        db,
        team_id=team_id,
        actor_id=user.id,
        action="member.remove",
        target=str(member_user_id),
    )
    return None


# --- Shared templates ----------------------------------------------------

@router.get("/{team_id}/templates", response_model=list[TemplateResponse])
async def list_templates(
    team_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List shared templates for a team (any member)."""
    await team_service.require_member(db, team_id, user.id)
    templates = (
        await db.execute(
            select(SharedTemplate).where(SharedTemplate.team_id == team_id)
        )
    ).scalars().all()
    return [_template_to_response(t) for t in templates]


@router.post("/{team_id}/templates", response_model=TemplateResponse, status_code=201)
async def create_template(
    team_id: uuid.UUID,
    request: TemplateCreateRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a shared template (any member)."""
    await team_service.require_member(db, team_id, user.id)

    template = SharedTemplate(
        team_id=team_id,
        created_by=user.id,
        name=request.name,
        description=request.description,
        content=json.dumps(request.content),
    )
    db.add(template)
    await db.flush()
    await team_service.record_audit(
        db,
        team_id=team_id,
        actor_id=user.id,
        action="template.create",
        target=str(template.id),
        detail=request.name,
    )
    return _template_to_response(template)


@router.delete(
    "/{team_id}/templates/{template_id}", status_code=status.HTTP_204_NO_CONTENT
)
async def delete_template(
    team_id: uuid.UUID,
    template_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a shared template (its creator, or an owner/admin)."""
    membership = await team_service.require_member(db, team_id, user.id)

    template = (
        await db.execute(
            select(SharedTemplate).where(
                SharedTemplate.id == template_id,
                SharedTemplate.team_id == team_id,
            )
        )
    ).scalar_one_or_none()
    if template is None:
        raise NotFoundError("Template")

    is_manager = membership.role in TeamRole.MANAGERS
    if not is_manager and template.created_by != user.id:
        raise AuthorizationError("Only the creator or a team manager can delete this")

    await db.delete(template)
    await team_service.record_audit(
        db,
        team_id=team_id,
        actor_id=user.id,
        action="template.delete",
        target=str(template_id),
    )
    return None


# --- Audit export --------------------------------------------------------

@router.get("/{team_id}/audit", response_model=AuditExportResponse)
async def export_audit(
    team_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Export the team's audit trail (owner/admin only)."""
    await team_service.require_manager(db, team_id, user.id)

    logs = (
        await db.execute(
            select(TeamAuditLog)
            .where(TeamAuditLog.team_id == team_id)
            .order_by(TeamAuditLog.created_at.desc())
        )
    ).scalars().all()

    entries = [
        AuditEntry(
            timestamp=log.created_at,
            action=log.action,
            actor_id=str(log.actor_id) if log.actor_id else "",
            target=log.target,
            detail=log.detail,
        )
        for log in logs
    ]
    return AuditExportResponse(
        team_id=str(team_id),
        generated_at=datetime.now(timezone.utc),
        count=len(entries),
        entries=entries,
    )


@router.get("/{team_id}/audit/csv")
async def export_audit_csv(
    team_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Export audit trail as CSV — E8.4 SIEM (owner/admin only)."""
    await team_service.require_manager(db, team_id, user.id)

    logs = (
        await db.execute(
            select(TeamAuditLog)
            .where(TeamAuditLog.team_id == team_id)
            .order_by(TeamAuditLog.created_at.asc())
        )
    ).scalars().all()

    import csv
    import io

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["timestamp", "action", "actor_id", "target", "detail", "prev_hash", "hash"])
    for log in logs:
        writer.writerow(
            [
                log.created_at.isoformat(),
                log.action,
                str(log.actor_id) if log.actor_id else "",
                log.target or "",
                log.detail or "",
                log.prev_hash or "",
                log.hash or "",
            ]
        )

    from fastapi.responses import StreamingResponse

    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="audit_{team_id}.csv"'},
    )


@router.get("/{team_id}/audit/cef")
async def export_audit_cef(
    team_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Export audit trail as CEF (Common Event Format) for SIEM — E8.4 (owner/admin)."""
    await team_service.require_manager(db, team_id, user.id)

    logs = (
        await db.execute(
            select(TeamAuditLog)
            .where(TeamAuditLog.team_id == team_id)
            .order_by(TeamAuditLog.created_at.asc())
        )
    ).scalars().all()

    # CEF: CEF:Version|Device Vendor|Device Product|Device Version|Signature ID|Name|Severity|Extension
    lines = []
    for log in logs:
        # Escape pipes and backslashes in extension values
        def esc(v: str) -> str:
            return v.replace("\\", "\\\\").replace("|", "\\|").replace("=", "\\=")

        extension = f"src={esc(str(log.actor_id) if log.actor_id else '')} "
        extension += f"dst={esc(str(team_id))} "
        extension += f"act={esc(log.action)} "
        extension += f"target={esc(log.target or '')} "
        extension += f"msg={esc(log.detail or '')} "
        extension += f"prevHash={esc(log.prev_hash or '')} "
        extension += f"hash={esc(log.hash or '')}"

        cef = f"CEF:0|AI-PDF|Teams|1.0|{esc(log.action)}|{esc(log.action)}|5|{extension}"
        lines.append(cef)

    from fastapi.responses import PlainTextResponse

    return PlainTextResponse(
        "\n".join(lines),
        media_type="text/plain",
        headers={"Content-Disposition": f'attachment; filename="audit_{team_id}.cef"'},
    )


@router.get("/{team_id}/audit/verify")
async def verify_audit_chain(
    team_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Verify audit log hash chain for tamper evidence — E8.4 (owner/admin)."""
    await team_service.require_manager(db, team_id, user.id)

    logs = (
        await db.execute(
            select(TeamAuditLog)
            .where(TeamAuditLog.team_id == team_id)
            .order_by(TeamAuditLog.created_at.asc())
        )
    ).scalars().all()

    tampered = []
    prev_hash_expected = "0" * 64

    for log in logs:
        if log.prev_hash != prev_hash_expected:
            tampered.append(
                {
                    "id": str(log.id),
                    "reason": f"prev_hash mismatch: expected {prev_hash_expected}, got {log.prev_hash}",
                    "timestamp": log.created_at.isoformat(),
                }
            )
        # Chain continuity check only (payload hash recompute is best-effort due to timestamp formatting)
        prev_hash_expected = log.hash or "0" * 64

    return {
        "team_id": str(team_id),
        "total_entries": len(logs),
        "tampered_entries": tampered,
        "is_valid": len(tampered) == 0,
        "note": "E8.4 hash chain verification — checks prev_hash continuity for tamper evidence of insertion/deletion. Full payload hash recompute is best-effort due to timestamp formatting.",
    }


# --- helpers -------------------------------------------------------------

def _template_to_response(t: SharedTemplate) -> TemplateResponse:
    try:
        content = json.loads(t.content) if t.content else {}
    except (ValueError, TypeError):
        content = {}
    return TemplateResponse(
        id=str(t.id),
        team_id=str(t.team_id),
        created_by=str(t.created_by) if t.created_by else None,
        name=t.name,
        description=t.description,
        content=content,
        created_at=t.created_at,
        updated_at=t.updated_at,
    )
