import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import 'package:ai_pdf/core/utils/error_text.dart';
import 'package:ai_pdf/core/widgets/button_spinner.dart';
import 'package:flutter/services.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:go_router/go_router.dart';
import 'package:pdfx/pdfx.dart' as pdfx;

import 'package:pdf/pdf.dart' show PdfPageFormat;
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';

import '../../../core/config/app_settings.dart';
import '../../../core/network/openrouter_service.dart';
import '../../../core/services/bm25_retriever.dart';
import '../../../core/services/form_memory_service.dart';
import '../../../core/services/ocr_service.dart';
import '../../../core/services/user_profile_service.dart';
import '../../profile/presentation/profile_screen.dart';
import '../../tools/models/filled_field.dart';
import '../../tools/presentation/pick_edit_screen.dart';
import '../../tools/widgets/result_sheet.dart';

/// The two AI experiences, both powered by the same on-device chat engine.
enum AiChatMode { understand, fillForm }

/// A smart, multi-turn AI chat that can SEE a document (PDF/image).
///
/// - Understand: ask anything about the document, conversationally.
/// - Fill Form: the AI reads the form, asks you for the info it needs, you
///   chat to provide it, and it produces the completed field values.
///
/// Runs directly on the phone through OpenRouter with the user's own key.
class AiChatScreen extends StatefulWidget {
  final AiChatMode mode;

  /// A document to open straight away (from the editor), instead of asking
  /// the user to pick one.
  final String? initialPath;
  const AiChatScreen({super.key, required this.mode, this.initialPath});

  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _ChatMsg {
  final String role; // 'user' | 'assistant'
  String text;
  _ChatMsg(this.role, this.text);
}

class _AiChatScreenState extends State<AiChatScreen> {
  // A3: send the whole document (bounded for memory/cost). Most forms/letters
  // are a few pages; capped resolution keeps each page light.
  static const int _maxPages = 12;
  static const double _renderMaxEdge = 1200;
  // Retrieval (RAG) covers more pages than we can send as images, at a lower
  // resolution used only for on-device OCR + citation indexing.
  static const int _ragMaxPages = 24;
  static const double _ocrMaxEdge = 1000;

  final _service = OpenRouterService();
  // On-device lexical retriever: grounds answers on the most relevant pages and
  // enables page citations, built in the background after a doc loads.
  final Bm25Retriever _retriever = Bm25Retriever();
  bool _indexTried = false;
  final _inputCtrl = TextEditingController();
  final _scroll = ScrollController();

  String? _fileName;
  String? _docPath; // original file path (for placing answers back on the form)
  bool _isPdf = false;
  List<String> _docImages = []; // data URLs attached to the first user turn
  // On-disk page images for OCR anchoring, keyed by 1-based page number so the
  // page->image mapping stays correct even if one page's temp write fails.
  Map<int, String> _pageImages = {};
  bool _placing = false;

  final List<_ChatMsg> _messages = [];
  bool _busy = false;
  bool _streaming = false;
  bool _loadingDoc = false;
  String? _error;

  String _profileBlock = ''; // the user's saved details, injected for form-fill
  String _memoryBlock = ''; // previously-answered fields, injected for form-fill

  bool get _isForm => widget.mode == AiChatMode.fillForm;


  String get _systemPrompt {
    if (_isForm) {
      final profile = _profileBlock.isNotEmpty
          ? '\n\nThe user has this saved profile — use it to PRE-FILL any matching '
              'fields automatically, and do NOT ask again for information already '
              'present here:\n$_profileBlock'
          : '';
      final memory = _memoryBlock.isNotEmpty
          ? '\n\nThe user has previously answered these fields on earlier forms — '
              'reuse a value ONLY when it clearly matches a field on this form, and '
              'confirm rather than assume when unsure:\n$_memoryBlock'
          : '';
      return 'You are an expert form-filling assistant. The user shares a form as page '
          'images (sometimes with extracted text). Do as much as possible automatically '
          'and keep questions to a minimum:\n'
          '1. Read the WHOLE form and identify every field, checkbox and signature line.\n'
          '2. For each, infer its type (text, name, date, email, phone, number, address, '
          'checkbox, choice, signature).\n'
          '3. Auto-fill everything you can from the saved profile and remembered answers '
          'below. Never ask for information already known.\n'
          '4. Give a short numbered overview: the fields you FILLED (with the value) and '
          'the fields you still NEED.\n'
          '5. Ask for all remaining fields together in ONE concise, plainly-worded '
          'message. Validate each answer against its field type and politely re-ask only '
          'if a value is clearly wrong (e.g. an invalid date or email).\n'
          '6. When you have enough, output the completed form as a clean list of '
          '"Field: Value" lines, note anything left blank, and remind the user they can '
          'tap "Place on form" to drop the answers onto the real PDF and export it.\n'
          'Be friendly and efficient. Prefer asking once for everything over many small '
          'questions, and never invent personal data.$profile$memory';
    }
    return 'You are a precise, helpful document assistant. The user shares a document '
        'as page images, sometimes with extracted text excerpts. Answer questions '
        'accurately based only on the document. When your answer draws on the '
        'document, cite the relevant page number(s) in parentheses, e.g. "(page 2)". '
        'For summaries, lead with a one-line overview, then short bold headers with '
        'bullet points. If something is not in the document, say so clearly. Be '
        'concise.';
  }

  @override
  void initState() {
    super.initState();
    if (_isForm) {
      UserProfileService.instance.load().then((_) {
        if (mounted) setState(() => _profileBlock = UserProfileService.instance.asPromptBlock());
      });
      FormMemoryService.instance.load().then((_) {
        if (mounted) setState(() => _memoryBlock = FormMemoryService.instance.asPromptBlock());
      });
    }
    final initial = widget.initialPath;
    if (initial != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _open(initial, initial.split(Platform.pathSeparator).last);
      });
    }
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png'],
    );
    if (result == null || result.files.isEmpty) return;
    final path = result.files.first.path;
    if (path == null) return;
    await _open(path, result.files.first.name);
  }

  Future<void> _open(String path, String name) async {
    setState(() {
      _loadingDoc = true;
      _error = null;
      _fileName = name;
      _docPath = path;
      _docImages = [];
      _pageImages = {};
      _messages.clear();
      _retriever.clear();
      _indexTried = false;
    });

    try {
      final lower = path.toLowerCase();
      if (lower.endsWith('.pdf')) {
        _isPdf = true;
        _docImages = await _renderPdf(path);
      } else {
        _isPdf = false;
        final bytes = await File(path).readAsBytes();
        final mime = lower.endsWith('.png') ? 'image/png' : 'image/jpeg';
        _docImages = [OpenRouterService.dataUrl(bytes, mime: mime)];
        _pageImages = {1: path}; // the image itself is page 1 for OCR
      }
      if (_docImages.isEmpty) {
        if (mounted) _error = AppLocalizations.of(context)!.aChatNoPages;
      } else if (_isForm) {
        // Kick off the form flow automatically.
        await _send(
          auto: 'Read my form. Give me a short numbered list of every field you '
              'found — marking which you already filled from my saved info and which '
              'you still need from me — then ask for all the missing ones together.',
        );
      } else {
        // Understand mode: build the retrieval index in the background so
        // questions can be grounded + cited without blocking the UI.
        _ensureIndex();
      }
    } catch (e) {
      if (mounted) _error = AppLocalizations.of(context)!.errReadFile(describeError(e, AppLocalizations.of(context)));
    } finally {
      if (mounted) setState(() => _loadingDoc = false);
    }
  }

  Future<List<String>> _renderPdf(String path) async {
    final urls = <String>[];
    _pageImages = {};
    Directory? tmp;
    try {
      tmp = await getTemporaryDirectory();
    } catch (_) {
      tmp = null;
    }
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final doc = await pdfx.PdfDocument.openFile(path);
    try {
      final count = doc.pagesCount < _maxPages ? doc.pagesCount : _maxPages;
      for (var i = 1; i <= count; i++) {
        final page = await doc.getPage(i);
        try {
          final longEdge = page.width > page.height ? page.width : page.height;
          final scale = longEdge > _renderMaxEdge ? _renderMaxEdge / longEdge : 1.0;
          final img = await page.render(
            width: page.width * scale,
            height: page.height * scale,
            format: pdfx.PdfPageImageFormat.jpeg,
            backgroundColor: '#FFFFFF',
          );
          final bytes = img?.bytes;
          if (bytes != null) {
            urls.add(OpenRouterService.dataUrl(Uint8List.fromList(bytes)));
            // Persist the page image so OCR can anchor placement precisely.
            if (tmp != null) {
              try {
                final p = '${tmp.path}/aiform_${stamp}_p$i.jpg';
                await File(p).writeAsBytes(bytes);
                _pageImages[i] = p;
              } catch (_) {
                // OCR anchoring is best-effort; ignore write failures.
              }
            }
          }
        } finally {
          await page.close();
        }
      }

      // Render extra pages BEYOND the image cap at low resolution, for OCR /
      // retrieval only. This lets the AI answer about — and cite — the whole
      // document, not just the first pages it can see as images.
      if (tmp != null && doc.pagesCount > count) {
        final ragMax =
            doc.pagesCount < _ragMaxPages ? doc.pagesCount : _ragMaxPages;
        for (var i = count + 1; i <= ragMax; i++) {
          final page = await doc.getPage(i);
          try {
            final longEdge =
                page.width > page.height ? page.width : page.height;
            final scale =
                longEdge > _ocrMaxEdge ? _ocrMaxEdge / longEdge : 1.0;
            final img = await page.render(
              width: page.width * scale,
              height: page.height * scale,
              format: pdfx.PdfPageImageFormat.jpeg,
              backgroundColor: '#FFFFFF',
            );
            final bytes = img?.bytes;
            if (bytes != null) {
              try {
                final p = '${tmp.path}/aiform_${stamp}_p$i.jpg';
                await File(p).writeAsBytes(bytes);
                _pageImages[i] = p;
              } catch (_) {
                // Best-effort; ignore write failures.
              }
            }
          } finally {
            await page.close();
          }
        }
      }
    } finally {
      await doc.close();
    }
    return urls;
  }

  /// Build the on-device retrieval index (OCR every rendered page, then index
  /// the text). Best-effort and runs once; failures degrade to no grounding.
  Future<void> _ensureIndex() async {
    if (_isForm || _indexTried || _pageImages.length < 2) return;
    _indexTried = true;
    try {
      final ocrByPage = await _ocrPages();
      final pageText = <int, String>{};
      ocrByPage.forEach((page, lines) {
        final t = lines.map((l) => l.text).join(' ').trim();
        if (t.isNotEmpty) pageText[page] = t;
      });
      if (pageText.isNotEmpty) _retriever.index(pageText);
    } catch (_) {
      // Retrieval is an enhancement; never let it break the chat.
    }
  }

  /// Run on-device OCR on each rendered page, returning page (1-based) → lines.
  /// Best-effort: returns an empty map if OCR is unavailable or fails.
  Future<Map<int, List<OcrLine>>> _ocrPages() async {
    final byPage = <int, List<OcrLine>>{};
    if (_pageImages.isEmpty) return byPage;
    final ocr = OcrService();
    try {
      for (final entry in _pageImages.entries) {
        try {
          final res = await ocr.recognize(entry.value);
          byPage[entry.key] = res.lines;
        } catch (_) {
          // Skip pages that fail OCR.
        }
      }
    } finally {
      await ocr.dispose();
    }
    return byPage;
  }

  /// Build a compact prompt block of detected label boxes for the AI to anchor
  /// placement against. Keeps only label-like lines, capped per page.
  String _anchorPrompt(Map<int, List<OcrLine>> byPage) {
    if (byPage.isEmpty) return '';
    final b = StringBuffer();
    byPage.forEach((page, lines) {
      var count = 0;
      for (final l in lines) {
        final t = l.text.trim().replaceAll('"', '');
        if (t.isEmpty) continue;
        // Prefer short labels or anything ending in a colon.
        if (t.length > 40 && !t.contains(':')) continue;
        b.writeln('p$page: "$t" (x${l.x.toStringAsFixed(2)},y${l.y.toStringAsFixed(2)})');
        if (++count >= 40) break;
      }
    });
    final s = b.toString();
    if (s.isEmpty) return '';
    return '\n\nDetected text labels on the pages (normalized coordinates). Use these '
        'to place each value ACCURATELY: set "anchor" to the EXACT label text you '
        'are filling next to so the value lands on the correct line:\n$s';
  }

  /// Snap a parsed field onto its matching OCR label box (just to the right of
  /// the label, vertically aligned). Returns the field unchanged if no match.
  List<FilledField> _snapToOcr(List<FilledField> fields, Map<int, List<OcrLine>> byPage) {
    if (byPage.isEmpty) return fields;
    String norm(String s) => s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
    final out = <FilledField>[];
    for (final f in fields) {
      final lines = byPage[f.page];
      if (f.anchor.isEmpty || lines == null || lines.isEmpty) {
        out.add(f);
        continue;
      }
      final a = norm(f.anchor);
      OcrLine? best;
      var bestScore = 0;
      for (final l in lines) {
        final t = norm(l.text);
        if (t.isEmpty) continue;
        var score = 0;
        if (t == a) {
          score = 1000;
        } else if (t.contains(a) || a.contains(t)) {
          score = a.length < t.length ? a.length : t.length;
        }
        if (score > bestScore) {
          bestScore = score;
          best = l;
        }
      }
      if (best != null && bestScore > 0) {
        final nx = (best.x + best.w + 0.012).clamp(0.0, 0.97);
        final ny = best.y.clamp(0.0, 0.97);
        out.add(f.withXY(nx.toDouble(), ny.toDouble()));
      } else {
        out.add(f);
      }
    }
    return out;
  }

  /// Build the full OpenAI-style message list. Document images are attached to
  /// the first user message so the model can see the pages.
  List<Map<String, dynamic>> _buildApiMessages({String? grounding}) {
    final systemContent = (grounding != null && grounding.isNotEmpty)
        ? '$_systemPrompt\n\n$grounding'
        : _systemPrompt;
    final msgs = <Map<String, dynamic>>[
      {'role': 'system', 'content': systemContent},
    ];
    var attached = false;
    for (final m in _messages) {
      if (m.role == 'user' && !attached && _docImages.isNotEmpty) {
        attached = true;
        msgs.add({
          'role': 'user',
          'content': [
            {'type': 'text', 'text': m.text},
            for (final url in _docImages)
              {'type': 'image_url', 'image_url': {'url': url}},
          ],
        });
      } else {
        msgs.add({'role': m.role, 'content': m.text});
      }
    }
    return msgs;
  }

  /// Clear the conversation but keep the loaded document + its retrieval index,
  /// so the user can start a fresh line of questions without re-picking a file.
  void _newChat() {
    if (_busy) return;
    setState(() {
      _messages.clear();
      _error = null;
      _inputCtrl.clear();
    });
  }

  Future<void> _send({String? auto}) async {
    final text = (auto ?? _inputCtrl.text).trim();
    if (text.isEmpty || _busy) return;
    if (_docImages.isEmpty) {
      setState(() => _error = AppLocalizations.of(context)!.aChatChooseDocFirst);
      return;
    }
    setState(() {
      _messages.add(_ChatMsg('user', text));
      if (auto == null) _inputCtrl.clear();
      _busy = true;
      _error = null;
    });
    _scrollToBottom();

    // Ground the answer on the most relevant pages (Understand mode) so it can
    // cite sources and reason over pages beyond those sent as images.
    String? grounding;
    if (!_isForm && !_retriever.isEmpty) {
      final hits = _retriever.search(text, topK: 5);
      if (hits.isNotEmpty) {
        final b = StringBuffer(
            'Relevant excerpts extracted on-device from the document. Use them to '
            'ground your answer and cite the page like "(page N)". If they do not '
            'contain the answer, rely on the page images:\n');
        for (final h in hits) {
          b.writeln('[page ${h.page}] ${h.text}');
        }
        grounding = b.toString();
      }
    }

    // Build request BEFORE adding the assistant placeholder.
    final apiMessages = _buildApiMessages(grounding: grounding);
    final assistant = _ChatMsg('assistant', '');
    setState(() {
      _messages.add(assistant);
      _streaming = true;
    });

    try {
      await _service.chatStream(apiMessages, onDelta: (d) {
        if (!mounted) return;
        setState(() => assistant.text += d);
        _scrollToBottom();
      });
      // Safety net: if nothing streamed, try a normal call.
      if (assistant.text.trim().isEmpty) {
        final reply = await _service.chat(apiMessages);
        if (mounted) setState(() => assistant.text = reply);
      }
    } on OpenRouterException catch (e) {
      // Streaming failed — try a normal (non-stream) call once before erroring.
      try {
        final reply = await _service.chat(apiMessages);
        if (mounted) setState(() => assistant.text = reply);
      } catch (_) {
        if (mounted) {
          setState(() {
            _messages.remove(assistant);
            _error = e.message;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _messages.remove(assistant);
          _error = AppLocalizations.of(context)!.operationFailed(describeError(e, AppLocalizations.of(context)));
        });
      }
    } finally {
      if (mounted) {
        setState(() {
            _busy = false;
            _streaming = false;
          });
      }
      _scrollToBottom();
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  /// Ask the AI for the filled values WITH positions, then open the editor with
  /// those values pre-placed on the actual form so the user can review/adjust
  /// and export a real filled PDF.
  Future<void> _placeOnForm() async {
    if (_docPath == null || _docImages.isEmpty || _placing) return;
    setState(() {
      _placing = true;
      _error = null;
    });
    try {
      // On-device OCR gives real label positions so placement is precise
      // instead of the model guessing pixel coordinates.
      final ocrByPage = await _ocrPages();
      final anchorBlock = _anchorPrompt(ocrByPage);

      // Add a hidden instruction turn requesting strict JSON with coordinates.
      final jsonMessages = _buildApiMessages()
        ..add({
          'role': 'user',
          'content':
              'Now output ONLY a JSON array (no prose, no code fences) of the values '
              'to write on the form based on everything above. Each item: '
              '{"field": "<short label of the field>", "page": <1-based page number>, '
              '"x": <0..1 from left edge>, "y": <0..1 from top edge>, '
              '"text": "<value to write>", '
              '"type": "text" | "check" | "signature", '
              '"confidence": "high" | "low", '
              '"anchor": "<exact detected label text to place next to, or empty>"}. '
              'Use type "check" for checkboxes/radios that should be ticked (set text '
              'to "yes"); omit boxes that stay empty. Use type "signature" for '
              'signature lines and set text to the person\'s full name. Set confidence '
              '"low" for any value or position you are unsure about. Place each value '
              'where its blank/answer line is on the page. Only include fields you have '
              'a value for.$anchorBlock',
        });

      final reply = await _service.chat(jsonMessages);
      final fields = _snapToOcr(_parseFields(reply), ocrByPage);

      if (fields.isEmpty) {
        if (!mounted) return;
        setState(() => _error = AppLocalizations.of(context)!.aChatPlaceNoFields);
        return;
      }

      if (!mounted) return;
      // A4: review & confirm before placing.
      final confirmed = await showModalBottomSheet<List<FilledField>>(
        context: context,
        isScrollControlled: true,
        builder: (_) => _FieldReviewSheet(fields: fields),
      );
      if (confirmed == null || confirmed.isEmpty) return;

      // Remember the confirmed answers so recurring fields auto-fill next time.
      final toRemember = <String, String>{};
      for (final f in confirmed) {
        if (f.field.trim().isNotEmpty && f.text.trim().isNotEmpty) {
          toRemember[f.field] = f.text;
        }
      }
      if (toRemember.isNotEmpty) {
        FormMemoryService.instance.remember(toRemember).then((_) {
          if (mounted) {
            setState(() => _memoryBlock = FormMemoryService.instance.asPromptBlock());
          }
        });
      }

      if (!mounted) return;
      await Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => PickEditScreen(initialPath: _docPath, initialFields: confirmed),
      ));
    } on OpenRouterException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = AppLocalizations.of(context)!.errPlaceAnswers(describeError(e, AppLocalizations.of(context))));
    } finally {
      if (mounted) setState(() => _placing = false);
    }
  }

  /// Extract a list of FilledField from a possibly-messy AI reply.
  List<FilledField> _parseFields(String reply) {
    final result = <FilledField>[];
    // Find the JSON array within the reply (strip prose / code fences).
    final start = reply.indexOf('[');
    final end = reply.lastIndexOf(']');
    if (start < 0 || end <= start) return result;
    final jsonStr = reply.substring(start, end + 1);
    try {
      final decoded = jsonDecode(jsonStr);
      if (decoded is List) {
        for (final item in decoded) {
          final f = FilledField.tryParse(item);
          if (f != null) result.add(f);
        }
      }
    } catch (_) {
      // Malformed JSON — return whatever we parsed (possibly empty).
    }
    return result;
  }

  /// Save an AI answer as a shareable PDF (and record it in Recent Files).
  Future<void> _saveAnswerPdf(String text) async {
    try {
      final doc = pw.Document();
      doc.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (_) => [
          pw.Header(level: 0, text: 'Pdoczy — Notes'),
          pw.SizedBox(height: 8),
          pw.Paragraph(text: text),
        ],
      ));
      final dir = await getApplicationDocumentsDirectory();
      final outPath = '${dir.path}/ai_notes_${DateTime.now().millisecondsSinceEpoch}.pdf';
      await File(outPath).writeAsBytes(await doc.save());
      if (mounted) {
        await showResultSheet(context,
            paths: [outPath],
            title: AppLocalizations.of(context)!.aiAnswer,
            subtitle: AppLocalizations.of(context)!.savedAsPdf);
      }
    } catch (e) {
      if (mounted) setState(() => _error = AppLocalizations.of(context)!.saveFailed(describeError(e, AppLocalizations.of(context))));
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final l10n = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(
        title: Text(_isForm ? l10n.fillFormWithAi : l10n.understandWithAi),
        actions: [
          // E2.3 Chat History — persisted sessions
          IconButton(
            tooltip: l10n.aChatHistoryTitle,
            icon: const Icon(Icons.history),
            onPressed: () => context.push('/ai/history'),
          ),
          if (_messages.isNotEmpty && !_busy)
            IconButton(
              tooltip: l10n.newChat,
              icon: const Icon(Icons.restart_alt),
              onPressed: _newChat,
            ),
          FutureBuilder<bool>(
            future: AppSettings.instance.hasOpenRouterKey(),
            builder: (_, snap) {
              if (snap.data != true) {
                return TextButton.icon(
                  onPressed: () => context.push('/settings'),
                  icon: const Icon(Icons.key, size: 16),
                  label: Text(l10n.addKey),
                );
              }
              return IconButton(
                tooltip: l10n.aiSettings,
                icon: const Icon(Icons.settings_outlined),
                onPressed: () => context.push('/settings'),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          _docBar(cs),
          if (_error != null) _errorBar(cs),
          Expanded(
            child: _docImages.isEmpty
                ? _emptyState(cs)
                : (_messages.isEmpty && !_isForm && !_busy
                    ? _suggestionView(cs)
                    : ListView.builder(
                        controller: _scroll,
                        padding: const EdgeInsets.all(12),
                        // Show the extra typing bubble only when busy AND not
                        // already streaming into an assistant bubble.
                        itemCount: _messages.length + ((_busy && !_streaming) ? 1 : 0),
                        itemBuilder: (_, i) {
                          if (i >= _messages.length) return _typingBubble(cs);
                          return _bubble(cs, _messages[i]);
                        },
                      )),
          ),
          if (_isForm && _docImages.isNotEmpty && _messages.length >= 2)
            _placeBar(cs),
          _quickActions(cs),
          if (_docImages.isNotEmpty) _inputBar(cs),
        ],
      ),
    );
  }

  Widget _placeBar(ColorScheme cs) {
    return Material(
      color: cs.primaryContainer.withValues(alpha: 0.4),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
        child: SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            onPressed: _placing ? null : _placeOnForm,
            icon: _placing
                ? const ButtonSpinner(size: 16)
                : const Icon(Icons.auto_fix_high),
            label: Text(_placing ? AppLocalizations.of(context)!.aChatPlacing : AppLocalizations.of(context)!.aChatPlaceAnswers),
          ),
        ),
      ),
    );
  }

  Widget _docBar(ColorScheme cs) {
    return Material(
      color: cs.surfaceContainerHighest,
      child: InkWell(
        onTap: _loadingDoc ? null : _pick,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Row(children: [
            Icon(
              _fileName == null
                  ? Icons.attach_file
                  : (_isPdf ? Icons.picture_as_pdf : Icons.image),
              size: 20,
              color: cs.primary,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                _fileName ?? AppLocalizations.of(context)!.aChatTapToChoose,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            if (_loadingDoc)
              const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
            else
              Text(_fileName == null ? '' : AppLocalizations.of(context)!.change,
                  style: TextStyle(color: cs.primary, fontSize: 12, fontWeight: FontWeight.w600)),
          ]),
        ),
      ),
    );
  }

  Widget _errorBar(ColorScheme cs) => Container(
        width: double.infinity,
        color: cs.errorContainer.withValues(alpha: 0.5),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(children: [
          Icon(Icons.error_outline, size: 18, color: cs.error),
          const SizedBox(width: 8),
          Expanded(child: Text(_error!, style: TextStyle(color: cs.onErrorContainer, fontSize: 13))),
        ]),
      );

  Widget _emptyState(ColorScheme cs) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(_isForm ? Icons.edit_document : Icons.auto_awesome, size: 64, color: cs.primary),
              const SizedBox(height: 16),
              Text(
                _isForm
                    ? AppLocalizations.of(context)!.aChatFormIntro
                    : AppLocalizations.of(context)!.aChatUnderstandIntro,
                textAlign: TextAlign.center,
                style: TextStyle(color: cs.onSurfaceVariant),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: _loadingDoc ? null : _pick,
                icon: const Icon(Icons.folder_open),
                label: Text(_isForm ? AppLocalizations.of(context)!.aChatChooseForm : AppLocalizations.of(context)!.chooseFile),
              ),
              if (_isForm) ...[
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const ProfileScreen()),
                  ),
                  icon: const Icon(Icons.badge_outlined, size: 18),
                  label: Text(AppLocalizations.of(context)!.setUpProfile),
                ),
              ],
            ],
          ),
        ),
      );

  Widget _bubble(ColorScheme cs, _ChatMsg m) {
    final isUser = m.role == 'user';
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
        decoration: BoxDecoration(
          color: isUser ? cs.primary : cs.surfaceContainerHighest,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(14),
            topRight: const Radius.circular(14),
            bottomLeft: Radius.circular(isUser ? 14 : 4),
            bottomRight: Radius.circular(isUser ? 4 : 14),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!isUser && m.text.isEmpty)
              const SizedBox(
                width: 18, height: 18,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            else
              SelectableText(
                m.text,
                style: TextStyle(
                  color: isUser ? Colors.white : cs.onSurface,
                  height: 1.35,
                ),
              ),
            // Copy / Save actions only once the answer has content.
            if (!isUser && m.text.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  _bubbleAction(cs, Icons.copy, AppLocalizations.of(context)!.copy, () async {
                    await Clipboard.setData(ClipboardData(text: m.text));
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text(AppLocalizations.of(context)!.copied)));
                    }
                  }),
                  const SizedBox(width: 14),
                  _bubbleAction(cs, Icons.picture_as_pdf_outlined, AppLocalizations.of(context)!.aChatSavePdf,
                      () => _saveAnswerPdf(m.text)),
                ]),
              ),
          ],
        ),
      ),
    );
  }

  Widget _bubbleAction(ColorScheme cs, IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 14, color: cs.onSurfaceVariant),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
      ]),
    );
  }

  /// Persistent quick-action chips shown above the input (like Adobe AI), even
  /// after the conversation starts, so the user can tap anytime.
  Widget _quickActions(ColorScheme cs) {
    if (_isForm || _docImages.isEmpty) return const SizedBox.shrink();
    final l10n = AppLocalizations.of(context)!;
    // Labels are shown in the UI; the second value is the prompt sent to the AI.
    final actions = [
      (l10n.aChatQaSummarize, 'Give a concise summary with key takeaways'),
      (l10n.aChatQaKeyFacts, 'List every important name, date, number and amount'),
      (l10n.aChatQaActionItems, 'What actions, tasks, or deadlines does this document require?'),
      (l10n.aChatQaTranslate, 'Translate the document into English'),
      (l10n.aChatQaExplain, 'Explain this document in simple terms a non-expert can understand'),
    ];
    return SizedBox(
      height: 38,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: actions.length,
        separatorBuilder: (_, __) => const SizedBox(width: 6),
        itemBuilder: (_, i) => ActionChip(
          avatar: const Icon(Icons.auto_awesome, size: 14),
          label: Text(actions[i].$1, style: const TextStyle(fontSize: 12)),
          onPressed: _busy ? null : () => _send(auto: actions[i].$2),
        ),
      ),
    );
  }

  /// Shown in Understand mode after a doc is loaded but before any question,
  /// to give the user quick starting points.
  Widget _suggestionView(ColorScheme cs) {
    final l10n = AppLocalizations.of(context)!;
    final suggestions = [
      l10n.aChatSuggestSummarize,
      l10n.aChatSuggestKeyData,
      l10n.aChatSuggestSimple,
      l10n.aChatSuggestTodo,
      l10n.aChatSuggestDeadlines,
    ];
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Icon(Icons.auto_awesome, size: 40, color: cs.primary),
        const SizedBox(height: 10),
        Text(l10n.askAboutYourDocument,
            textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
        const SizedBox(height: 16),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          alignment: WrapAlignment.center,
          children: suggestions
              .map((s) => ActionChip(
                    label: Text(s),
                    onPressed: () {
                      if (!_busy) _send(auto: s);
                    },
                  ))
              .toList(),
        ),
      ],
    );
  }

  Widget _typingBubble(ColorScheme cs) => Align(
        alignment: Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cs.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(14),
          ),
          child: const SizedBox(
            width: 20, height: 20,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
        ),
      );

  Widget _inputBar(ColorScheme cs) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
        decoration: BoxDecoration(
          color: cs.surface,
          boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, -1))],
        ),
        child: Row(children: [
          Expanded(
            child: TextField(
              controller: _inputCtrl,
              minLines: 1,
              maxLines: 4,
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => _send(),
              decoration: InputDecoration(
                hintText: _isForm
                    ? AppLocalizations.of(context)!.typeYourInfo
                    : AppLocalizations.of(context)!.askAboutTheDocument,
                filled: true,
                fillColor: cs.surfaceContainerHighest,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          const SizedBox(width: 6),
          IconButton.filled(
            tooltip: AppLocalizations.of(context)!.a11ySend,
            onPressed: _busy ? null : () => _send(),
            icon: const Icon(Icons.send),
          ),
        ]),
      ),
    );
  }
}

/// Review & confirm sheet shown before placing answers on the form.
/// Lets the user edit each value and untick ones they don't want placed.
class _FieldReviewSheet extends StatefulWidget {
  final List<FilledField> fields;
  const _FieldReviewSheet({required this.fields});

  @override
  State<_FieldReviewSheet> createState() => _FieldReviewSheetState();
}

class _FieldReviewSheetState extends State<_FieldReviewSheet> {
  late final List<TextEditingController> _ctrls;
  late final List<bool> _include;

  @override
  void initState() {
    super.initState();
    _ctrls = widget.fields.map((f) => TextEditingController(text: f.text)).toList();
    _include = List<bool>.filled(widget.fields.length, true);
  }

  @override
  void dispose() {
    for (final c in _ctrls) {
      c.dispose();
    }
    super.dispose();
  }

  void _confirm() {
    final out = <FilledField>[];
    for (var i = 0; i < widget.fields.length; i++) {
      if (!_include[i]) continue;
      final v = _ctrls[i].text.trim();
      if (v.isEmpty) continue;
      out.add(widget.fields[i].withText(v));
    }
    Navigator.pop(context, out);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final l10n = AppLocalizations.of(context)!;
    final count = _include.where((e) => e).length;
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.7,
      maxChildSize: 0.95,
      minChildSize: 0.4,
      builder: (context, scrollCtrl) => Column(
        children: [
          const SizedBox(height: 10),
          Container(width: 40, height: 4, decoration: BoxDecoration(color: cs.outlineVariant, borderRadius: BorderRadius.circular(2))),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Row(children: [
              Icon(Icons.fact_check_outlined, color: cs.primary),
              const SizedBox(width: 8),
              Expanded(
                child: Text(l10n.reviewBeforePlacing,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(l10n.editAnyValue,
                  style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView.separated(
              controller: scrollCtrl,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: widget.fields.length,
              separatorBuilder: (_, __) => const SizedBox(height: 6),
              itemBuilder: (context, i) {
                final f = widget.fields[i];
                IconData typeIcon = Icons.text_fields;
                if (f.isCheck) typeIcon = Icons.check_box_outlined;
                if (f.isSignature) typeIcon = Icons.draw_outlined;
                return Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                  Checkbox(
                    value: _include[i],
                    onChanged: (v) => setState(() => _include[i] = v ?? true),
                  ),
                  Tooltip(
                    message: f.isCheck
                        ? l10n.markCheckbox
                        : (f.isSignature ? l10n.fieldKindSignature : l10n.fieldKindText),
                    child: Icon(typeIcon, size: 18, color: cs.onSurfaceVariant),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _ctrls[i],
                      decoration: InputDecoration(
                        labelText: f.field.isNotEmpty ? f.field : l10n.aChatValueOnPage(f.page),
                        isDense: true,
                        border: const OutlineInputBorder(),
                        suffixIcon: f.uncertain
                            ? Tooltip(
                                message: l10n.aChatAiUnsure,
                                child: const Icon(Icons.warning_amber_rounded,
                                    size: 20, color: Color(0xFFCF9A4E)),
                              )
                            : null,
                      ),
                    ),
                  ),
                ]);
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text(l10n.cancel),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: count == 0 ? null : _confirm,
                    icon: const Icon(Icons.auto_fix_high),
                    label: Text(l10n.placeNValues(count)),
                  ),
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
