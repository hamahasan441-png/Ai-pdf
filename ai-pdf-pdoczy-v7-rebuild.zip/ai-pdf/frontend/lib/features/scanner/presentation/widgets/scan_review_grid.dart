import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import 'package:ai_pdf/features/scanner/presentation/widgets/scan_filter_label.dart';
import 'package:ai_pdf/features/scanner/domain/entities/scan_page.dart';

/// Reorderable grid of captured pages for the review stage (Phase 51).
///
/// Each tile shows the processed thumbnail, a page number, and quick actions
/// (rotate, edit crop, delete). Long-press-drag reorders pages.
class ScanReviewGrid extends StatelessWidget {
  final List<ScanPage> pages;
  final ValueChanged<String> onEdit;
  final ValueChanged<String> onRotate;
  final ValueChanged<String> onDelete;
  final void Function(int oldIndex, int newIndex) onReorder;

  const ScanReviewGrid({
    super.key,
    required this.pages,
    required this.onEdit,
    required this.onRotate,
    required this.onDelete,
    required this.onReorder,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final l = AppLocalizations.of(context)!;
    return ReorderableListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: pages.length,
      onReorder: onReorder,
      proxyDecorator: (child, index, animation) => Material(
        elevation: 6,
        color: Colors.transparent,
        child: child,
      ),
      itemBuilder: (context, i) {
        final page = pages[i];
        return Card(
          key: ValueKey(page.id),
          margin: const EdgeInsets.only(bottom: 10),
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                // Thumbnail
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: SizedBox(
                    width: 64,
                    height: 84,
                    child: page.processing
                        ? const Center(
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          )
                        : Image.memory(page.displayBytes, fit: BoxFit.cover),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(l.pageNumber(i + 1),
                              style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: cs.onSurface)),
                          if (page.hasOcrText) ...[
                            const SizedBox(width: 6),
                            Icon(Icons.text_snippet,
                                size: 14, color: cs.primary),
                          ],
                        ],
                      ),
                      Text(scanFilterLabel(AppLocalizations.of(context)!, page.filter),
                          style: TextStyle(
                              fontSize: 12, color: cs.onSurfaceVariant)),
                      if (page.hasOcrText)
                        Text(l.bScanTextDetected,
                            style: TextStyle(
                                fontSize: 11, color: cs.primary)),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.rotate_right, size: 20),
                  onPressed: () => onRotate(page.id),
                  tooltip: l.rotate,
                ),
                IconButton(
                  icon: const Icon(Icons.crop, size: 20),
                  onPressed: () => onEdit(page.id),
                  tooltip: l.bScanAdjustCrop,
                ),
                IconButton(
                  icon: Icon(Icons.delete_outline, size: 20, color: cs.error),
                  onPressed: () => onDelete(page.id),
                  tooltip: l.delete,
                ),
                ReorderableDragStartListener(
                  index: i,
                  child: Icon(Icons.drag_handle, color: cs.onSurfaceVariant),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
