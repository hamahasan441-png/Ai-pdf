import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import 'package:ai_pdf/core/utils/error_text.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';

import 'package:ai_pdf/features/scanner/application/scanner_controller.dart';
import 'package:ai_pdf/features/scanner/data/scan_image_processor.dart';
import 'package:ai_pdf/features/editor/data/pdf_unicode_fonts.dart';
import 'package:ai_pdf/features/scanner/data/scan_ocr_service.dart';
import 'package:ai_pdf/features/scanner/data/scan_pdf_builder.dart';
import 'package:ai_pdf/features/scanner/domain/entities/document_corners.dart';
import 'package:ai_pdf/features/scanner/domain/entities/scan_filter.dart';
import 'package:ai_pdf/features/scanner/domain/entities/scan_page.dart';
import 'package:ai_pdf/features/scanner/domain/services/document_detection_service.dart';
import 'package:ai_pdf/features/scanner/presentation/widgets/scan_crop_editor.dart';
import 'package:ai_pdf/features/scanner/presentation/widgets/scan_filter_bar.dart';
import 'package:ai_pdf/features/scanner/presentation/widgets/scan_review_grid.dart';
import 'package:ai_pdf/features/scanner/presentation/widgets/scan_text_result_sheet.dart';

/// Isolate-sendable job describing one page's dewarp + filter.
class ScanProcessJob {
  final Uint8List bytes;
  final List<double> cornerCoords; // [tlx,tly,trx,try,brx,bry,blx,bly]
  final int filterIndex;
  final int rotationQuarterTurns;

  const ScanProcessJob({
    required this.bytes,
    required this.cornerCoords,
    required this.filterIndex,
    required this.rotationQuarterTurns,
  });
}

/// Top-level entry for `compute` — dewarps and filters one page off the UI
/// thread. Returns processed JPEG bytes (or null on failure).
Uint8List? runScanProcessJob(ScanProcessJob job) {
  final c = job.cornerCoords;
  final corners = DocumentCorners(
    topLeft: ui.Offset(c[0], c[1]),
    topRight: ui.Offset(c[2], c[3]),
    bottomRight: ui.Offset(c[4], c[5]),
    bottomLeft: ui.Offset(c[6], c[7]),
  );
  return const ScanImageProcessor().process(
    sourceBytes: job.bytes,
    corners: corners,
    filter: ScanFilter.values[job.filterIndex],
    rotationQuarterTurns: job.rotationQuarterTurns,
  );
}

/// The professional document scanner screen (Phase 51).
///
/// Flow: capture (system camera) -> auto edge-detect + crop editor -> filter
/// -> review grid (reorder / rotate / delete) -> text detection (OCR) ->
/// export multi-page PDF (searchable or image-only).
class ScannerScreen extends ConsumerStatefulWidget {
  const ScannerScreen({super.key});

  @override
  ConsumerState<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends ConsumerState<ScannerScreen> {
  final ImagePicker _picker = ImagePicker();
  static const _detector = DocumentDetectionService();
  static const _processor = ScanImageProcessor();
  static const _ocrService = ScanOcrService();

  /// Original-image pixel sizes keyed by page id (for the crop editor mapping).
  final Map<String, ui.Size> _sizes = {};

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(scannerControllerProvider);
    final l = AppLocalizations.of(context)!;
    return Scaffold(
      backgroundColor: const Color(0xFF141414),
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(_titleFor(l, state.stage)),
        actions: [
          if (state.hasPages && state.stage != ScanStage.reviewing)
            TextButton.icon(
              icon: const Icon(Icons.grid_view, color: Colors.white),
              label: Text('${state.pageCount}',
                  style: const TextStyle(color: Colors.white)),
              onPressed: () =>
                  ref.read(scannerControllerProvider.notifier).goToReview(),
            ),
        ],
      ),
      body: switch (state.stage) {
        ScanStage.capturing => _captureView(state),
        ScanStage.cropping => _cropView(state),
        ScanStage.reviewing => _reviewView(state),
        ScanStage.textDetection => _textDetectionView(state),
      },
    );
  }

  String _titleFor(AppLocalizations l, ScanStage stage) => switch (stage) {
        ScanStage.capturing => l.bScanTitleCapture,
        ScanStage.cropping => l.bScanTitleCrop,
        ScanStage.reviewing => l.bScanTitleReview,
        ScanStage.textDetection => l.bScanTitleText,
      };

  // ── Capture ──────────────────────────────────────────────────────────────

  Widget _captureView(ScannerState state) {
    final l = AppLocalizations.of(context)!;
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.document_scanner_outlined,
              size: 96, color: Colors.white24),
          const SizedBox(height: 16),
          Text(
            l.bScanPointCamera,
            style: const TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 32),
          FilledButton.icon(
            icon: const Icon(Icons.camera_alt),
            label: Text(state.hasPages ? l.bScanCaptureNext : l.bScanCapture),
            onPressed: _capture,
            style: FilledButton.styleFrom(
              padding:
                  const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            ),
          ),
          const SizedBox(height: 12),
          TextButton.icon(
            icon: const Icon(Icons.photo_library_outlined, color: Colors.white70),
            label: Text(l.bScanImportGallery,
                style: const TextStyle(color: Colors.white70)),
            onPressed: _importFromGallery,
          ),
          const SizedBox(height: 8),
          TextButton.icon(
            icon: const Icon(Icons.collections_outlined, color: Colors.white70),
            label: Text(l.bScanBatchImport,
                style: const TextStyle(color: Colors.white70)),
            onPressed: _batchImportFromGallery,
          ),
          if (state.error != null) ...[
            const SizedBox(height: 16),
            Text(state.error!, style: const TextStyle(color: Colors.redAccent)),
          ],
        ],
      ),
    );
  }

  Future<void> _capture() => _pick(ImageSource.camera);
  Future<void> _importFromGallery() => _pick(ImageSource.gallery);

  Future<void> _pick(ImageSource source) async {
    final controller = ref.read(scannerControllerProvider.notifier);
    try {
      final file = await _picker.pickImage(
        source: source,
        imageQuality: 100,
        maxWidth: 3000,
        maxHeight: 3000,
      );
      if (file == null) return;
      final bytes = await file.readAsBytes();
      _addPageFromBytes(bytes);
    } catch (e) {
      if (mounted) controller.setError(AppLocalizations.of(context)!.errCapture(describeError(e, AppLocalizations.of(context))));
    }
  }

  /// Batch import: pick multiple images from the gallery at once.
  Future<void> _batchImportFromGallery() async {
    final controller = ref.read(scannerControllerProvider.notifier);
    try {
      final files = await _picker.pickMultiImage(
        imageQuality: 100,
        maxWidth: 3000,
        maxHeight: 3000,
      );
      if (files.isEmpty) return;
      for (final file in files) {
        final bytes = await file.readAsBytes();
        _addPageFromBytes(bytes);
      }
    } catch (e) {
      if (mounted) controller.setError(AppLocalizations.of(context)!.errImport(describeError(e, AppLocalizations.of(context))));
    }
  }

  /// Shared logic for adding a page from raw image bytes.
  void _addPageFromBytes(Uint8List bytes) {
    final controller = ref.read(scannerControllerProvider.notifier);
    final input = _processor.extractDetectionInput(bytes);
    final DocumentCorners corners;
    final ui.Size size;
    if (input == null) {
      size = const ui.Size(1000, 1400);
      corners = DocumentCorners.insetFrame(size, 0.05);
    } else {
      size = input.fullSize;
      final result = _detector.estimateFromEnergy(
        input.rowEnergy,
        input.colEnergy,
        input.fullSize,
      );
      corners = result.corners;
    }

    final page = controller.addCapture(bytes, corners);
    _sizes[page.id] = size;
    _process(page.id);
  }

  // ── Crop ─────────────────────────────────────────────────────────────────

  Widget _cropView(ScannerState state) {
    final page = state.activePage;
    if (page == null) {
      return Center(
          child: Text(AppLocalizations.of(context)!.bScanNoPage,
              style: const TextStyle(color: Colors.white)));
    }
    final size = _sizes[page.id] ?? const ui.Size(1000, 1400);
    return Column(
      children: [
        Expanded(
          child: ScanCropEditor(
            imageBytes: page.originalBytes,
            imageSize: size,
            corners: page.corners,
            onCornersChanged: (c) => ref
                .read(scannerControllerProvider.notifier)
                .updateCorners(c, pageId: page.id),
          ),
        ),
        ScanFilterBar(
          selected: page.filter,
          onSelected: (f) => ref
              .read(scannerControllerProvider.notifier)
              .setFilter(f, pageId: page.id),
        ),
        _cropActions(page),
      ],
    );
  }

  Widget _cropActions(ScanPage page) {
    final l = AppLocalizations.of(context)!;
    return Container(
      color: Colors.black,
      padding: const EdgeInsets.all(12),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            IconButton(
              icon: const Icon(Icons.rotate_right, color: Colors.white),
              tooltip: l.rotate,
              onPressed: () => ref
                  .read(scannerControllerProvider.notifier)
                  .rotatePage(pageId: page.id),
            ),
            const Spacer(),
            FilledButton(
              onPressed: () async {
                await _process(page.id);
                ref.read(scannerControllerProvider.notifier).confirmCrop();
              },
              child: Text(l.done),
            ),
          ],
        ),
      ),
    );
  }

  // ── Review ─────────────────────────────────────────────────────────────

  Widget _reviewView(ScannerState state) {
    final controller = ref.read(scannerControllerProvider.notifier);
    final l = AppLocalizations.of(context)!;
    return Column(
      children: [
        Expanded(
          child: state.hasPages
              ? ScanReviewGrid(
                  pages: state.pages,
                  onEdit: controller.editPage,
                  onRotate: (id) async {
                    controller.rotatePage(pageId: id);
                    await _process(id);
                  },
                  onDelete: controller.deletePage,
                  onReorder: controller.reorderPages,
                )
              : Center(
                  child: Text(l.bScanNoPagesYet,
                      style: const TextStyle(color: Colors.white70)),
                ),
        ),
        Container(
          color: Colors.black,
          padding: const EdgeInsets.all(12),
          child: SafeArea(
            top: false,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    OutlinedButton.icon(
                      icon: const Icon(Icons.add_a_photo, color: Colors.white),
                      label: Text(l.bScanAddPage,
                          style: const TextStyle(color: Colors.white)),
                      onPressed: controller.resumeCapture,
                    ),
                    const Spacer(),
                    OutlinedButton.icon(
                      icon:
                          const Icon(Icons.text_fields, color: Colors.white),
                      label: Text(l.bScanDetectText,
                          style: const TextStyle(color: Colors.white)),
                      onPressed: state.hasPages ? _startOcr : null,
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        icon: state.exporting
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2, color: Colors.white),
                              )
                            : const Icon(Icons.picture_as_pdf),
                        label: Text(l.exportPdf),
                        onPressed:
                            state.exporting || !state.hasPages ? null : _exportPdf,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton.icon(
                        icon: state.exporting
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2, color: Colors.white),
                              )
                            : const Icon(Icons.save_alt),
                        label: Text(l.saveToDevice),
                        onPressed:
                            state.exporting || !state.hasPages ? null : _saveToDevice,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ── Text Detection ─────────────────────────────────────────────────────

  Widget _textDetectionView(ScannerState state) {
    final controller = ref.read(scannerControllerProvider.notifier);
    final l = AppLocalizations.of(context)!;
    return Column(
      children: [
        if (state.isOcrRunning)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                LinearProgressIndicator(
                  value: state.pageCount > 0
                      ? (state.ocrProgressIndex + 1) / state.pageCount
                      : null,
                ),
                const SizedBox(height: 8),
                Text(
                  l.bScanProcessingPage(state.ocrProgressIndex + 1, state.pageCount),
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
        // Show OCR failure warning if any pages failed.
        if (!state.isOcrRunning && state.ocrFailedPages > 0)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: Colors.orange.shade900.withValues(alpha: 0.3),
            child: Row(
              children: [
                const Icon(Icons.warning_amber_rounded,
                    color: Colors.orangeAccent, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    l.bScanOcrFailed(state.ocrFailedPages),
                    style: const TextStyle(
                        color: Colors.orangeAccent, fontSize: 13),
                  ),
                ),
              ],
            ),
          ),
        Expanded(
          child: state.recognizedText.isEmpty && !state.isOcrRunning
              ? Center(
                  child: Text(
                    l.bScanNoTextDetectedRetry,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white70),
                  ),
                )
              : state.isOcrRunning
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const CircularProgressIndicator(),
                          const SizedBox(height: 16),
                          Text(l.bScanRunningOcr,
                              style: const TextStyle(color: Colors.white70)),
                        ],
                      ),
                    )
                  : SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: SelectableText(
                        state.recognizedText,
                        style: const TextStyle(
                          fontSize: 14,
                          height: 1.5,
                          color: Colors.white,
                        ),
                      ),
                    ),
        ),
        Container(
          color: Colors.black,
          padding: const EdgeInsets.all(12),
          child: SafeArea(
            top: false,
            child: Row(
              children: [
                OutlinedButton.icon(
                  icon: const Icon(Icons.arrow_back, color: Colors.white),
                  label: Text(l.bCommonBack,
                      style: const TextStyle(color: Colors.white)),
                  onPressed: controller.goToReview,
                ),
                const Spacer(),
                if (state.recognizedText.isNotEmpty && !state.isOcrRunning) ...[
                  IconButton(
                    icon: const Icon(Icons.copy, color: Colors.white),
                    tooltip: l.bScanCopyAllText,
                    onPressed: () async {
                      await Clipboard.setData(
                          ClipboardData(text: state.recognizedText));
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text(l.copiedToClipboard)),
                        );
                      }
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.share, color: Colors.white),
                    tooltip: l.bScanShareText,
                    onPressed: () async {
                      await Share.share(
                        state.recognizedText,
                        subject: l.bScanSubject,
                      );
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.description, color: Colors.white),
                    tooltip: l.bScanViewFormatted,
                    onPressed: () => ScanTextResultSheet.show(
                      context,
                      text: state.recognizedText,
                      onRescan: _startOcr,
                    ),
                  ),
                  FilledButton.icon(
                    icon: const Icon(Icons.picture_as_pdf),
                    label: Text(l.bScanSearchablePdf),
                    onPressed: () => _exportPdf(forceSearchable: true),
                  ),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ── OCR Flow ─────────────────────────────────────────────────────────────

  /// Start OCR on all pages and navigate to text detection view.
  ///
  /// Uses page IDs captured upfront and re-reads state each iteration to avoid
  /// stale-list issues if pages are modified concurrently.
  Future<void> _startOcr() async {
    final controller = ref.read(scannerControllerProvider.notifier);
    controller.goToTextDetection();

    // Capture page IDs upfront - iterate by ID, not by stale list reference.
    final pageIds = ref.read(scannerControllerProvider).pages
        .map((p) => p.id)
        .toList();

    for (var i = 0; i < pageIds.length; i++) {
      final pageId = pageIds[i];

      // Re-read state each iteration to get current page data.
      final currentState = ref.read(scannerControllerProvider);
      final page = currentState.pages.cast<ScanPage?>().firstWhere(
        (p) => p?.id == pageId,
        orElse: () => null,
      );

      // Skip if page was deleted during OCR.
      if (page == null) continue;

      controller.setOcrProgress(i);
      controller.markOcrProcessing(pageId, true);
      try {
        final result = await _ocrService.extractWithPositions(page.displayBytes);
        controller.setPageOcrResult(pageId, result);
      } catch (e) {
        controller.markPageOcrFailed(pageId);
      }
    }
    controller.finishOcr();
  }

  // ── Processing & export ──────────────────────────────────────────────────

  Future<void> _process(String pageId) async {
    final controller = ref.read(scannerControllerProvider.notifier);
    final state = ref.read(scannerControllerProvider);
    final page = state.pages.cast<ScanPage?>().firstWhere(
        (p) => p?.id == pageId,
        orElse: () => null);
    if (page == null) return;

    controller.markProcessing(pageId, true);
    final c = page.corners;
    final job = ScanProcessJob(
      bytes: page.originalBytes,
      cornerCoords: [
        c.topLeft.dx, c.topLeft.dy,
        c.topRight.dx, c.topRight.dy,
        c.bottomRight.dx, c.bottomRight.dy,
        c.bottomLeft.dx, c.bottomLeft.dy,
      ],
      filterIndex: page.filter.index,
      rotationQuarterTurns: page.rotationQuarterTurns,
    );
    try {
      final result = await compute(runScanProcessJob, job);
      if (result != null) {
        controller.setProcessed(pageId, result);
      } else {
        controller.markProcessing(pageId, false);
      }
    } catch (e) {
      controller.markProcessing(pageId, false);
      if (mounted) controller.setError(AppLocalizations.of(context)!.errProcessing(describeError(e, AppLocalizations.of(context))));
    }
  }

  Future<void> _exportPdf({bool forceSearchable = false}) async {
    final controller = ref.read(scannerControllerProvider.notifier);
    final state = ref.read(scannerControllerProvider);
    final shareText = AppLocalizations.of(context)!.bScanShareDocument;
    controller.beginExport();
    try {
      final bytes = await _buildPdf(state.pages, forceSearchable || state.searchablePdf);
      final dir = await getTemporaryDirectory();
      final path = await _writeAtomically(bytes, dir.path);
      controller.finishExport();
      await Share.shareXFiles([XFile(path)], text: shareText);
    } catch (e) {
      if (mounted) controller.setError(AppLocalizations.of(context)!.errExport(describeError(e, AppLocalizations.of(context))));
    }
  }

  /// One builder for share and save, so both files are the same.
  Future<Uint8List> _buildPdf(List<ScanPage> pages, bool searchable) async {
    pw.Font? font;
    if (searchable) {
      final fonts = PdfUnicodeFonts();
      await fonts.load();
      font = fonts.notoSans;
    }
    return const ScanPdfBuilder().build(pages, searchable: searchable, textFont: font);
  }

  Future<String> _writeAtomically(Uint8List bytes, String dir) async {
    final path = '$dir/scan_${DateTime.now().millisecondsSinceEpoch}.pdf';
    final partial = File('$path.partial');
    await partial.writeAsBytes(bytes, flush: true);
    await partial.rename(path);
    return path;
  }

  /// Save PDF directly to the device's documents directory.
  Future<void> _saveToDevice() async {
    final controller = ref.read(scannerControllerProvider.notifier);
    final state = ref.read(scannerControllerProvider);
    controller.beginExport();
    try {
      final bytes = await _buildPdf(state.pages, state.searchablePdf);
      final dir = await getApplicationDocumentsDirectory();
      final path = await _writeAtomically(bytes, dir.path);
      controller.finishExport();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(AppLocalizations.of(context)!.bScanSavedTo(path)),
            duration: const Duration(seconds: 4),
            action: SnackBarAction(
              label: AppLocalizations.of(context)!.ok,
              onPressed: () {},
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) controller.setError(AppLocalizations.of(context)!.saveFailed(describeError(e, AppLocalizations.of(context))));
    }
  }
}
