import 'annotation.dart';
import 'form_field_annotation.dart';
import 'image_annotation.dart';
import 'stamp_annotation.dart';
import 'sticky_note_annotation.dart';
import 'text_markup_annotation.dart';

/// Per-page annotation layer with undo + redo history.
///
/// [findById] lets controllers and undo commands locate an annotation by its
/// stable [EditorAnnotation.id] instead of relying on object-identity, which
/// breaks after clone / paste operations.
class PageLayer {
  final List<EditorAnnotation> items = [];
  final List<EditorAnnotation> redo = [];

  List<StrokeAnnotation> get strokes =>
      items.whereType<StrokeAnnotation>().toList();
  List<ShapeAnnotation> get shapes =>
      items.whereType<ShapeAnnotation>().toList();
  List<TextAnnotation> get texts =>
      items.whereType<TextAnnotation>().toList();
  List<ImageAnnotation> get images =>
      items.whereType<ImageAnnotation>().toList();
  List<StampAnnotation> get stamps =>
      items.whereType<StampAnnotation>().toList();
  List<TextMarkupAnnotation> get markups =>
      items.whereType<TextMarkupAnnotation>().toList();
  List<FormFieldAnnotation> get fields =>
      items.whereType<FormFieldAnnotation>().toList();
  List<StickyNoteAnnotation> get notes =>
      items.whereType<StickyNoteAnnotation>().toList();

  /// Returns the first annotation whose [id] matches, or null.
  EditorAnnotation? findById(String id) {
    try {
      return items.firstWhere((a) => a.id == id);
    } catch (_) {
      return null;
    }
  }

}
