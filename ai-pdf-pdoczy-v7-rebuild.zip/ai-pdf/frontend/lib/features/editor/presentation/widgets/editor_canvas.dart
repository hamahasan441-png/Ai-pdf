import 'dart:typed_data';

import 'package:flutter/material.dart';

import 'package:ai_pdf/core/services/ocr_service.dart';
import 'package:ai_pdf/features/editor/data/editor_text_runs.dart';
import 'package:ai_pdf/features/editor/data/image_annotation_renderer.dart';
import 'package:ai_pdf/features/editor/data/stamp_annotation_renderer.dart';
import 'package:ai_pdf/features/editor/domain/entities/annotation.dart';
import 'package:ai_pdf/features/editor/domain/entities/form_field_annotation.dart';
import 'package:ai_pdf/features/editor/domain/entities/detected_field.dart';
import 'package:ai_pdf/features/editor/domain/entities/editor_tool.dart';
import 'package:ai_pdf/features/editor/domain/entities/image_annotation.dart';
import 'package:ai_pdf/features/editor/domain/entities/page_layer.dart';
import 'package:ai_pdf/features/editor/domain/entities/stamp_annotation.dart';
import 'package:ai_pdf/features/editor/domain/entities/sticky_note_annotation.dart';
import 'package:ai_pdf/features/editor/domain/entities/text_markup_annotation.dart';
import 'package:ai_pdf/features/editor/presentation/widgets/editor_canvas_painter.dart';
import 'package:ai_pdf/features/editor/presentation/widgets/edit_text_target.dart';
import 'package:ai_pdf/features/editor/presentation/widgets/editor_design.dart';
import 'package:ai_pdf/features/editor/presentation/widgets/form_field_box.dart';
import 'package:ai_pdf/features/editor/presentation/widgets/editor_selection_overlay.dart';
import 'package:ai_pdf/features/editor/presentation/widgets/sticky_note_widget.dart';

class EditorCanvas extends StatelessWidget {
  final Uint8List bytes;
  final EditTool tool;
  final PageLayer layer;
  final List<Offset> drawing;
  final Offset? shapeStart;
  final Offset? shapeEnd;
  final ShapeType? previewShapeType;
  final Color color;
  final double stroke;
  final bool highlightPreview;
  final bool securePreview;
  final List<Rect> markupPreview;
  final TextMarkupKind? markupKind;
  final List<Rect> findRects;
  final int activeFind;
  final List<Rect> wordSelection;
  final bool showFields;
  final List<DetectedField> pageFields;
  final bool showEditLines;
  final List<OcrLine> editLines;
  final double? guideX;
  final double? guideY;
  final Set<EditorAnnotation> multi;
  final String selMode;
  final Offset? marqueeStart;
  final Offset? marqueeEnd;
  final EditorAnnotation? selected;
  final Rect Function(EditorAnnotation) boundsOf;
  final ImageAnnotationRenderer imageRenderer;
  final StampAnnotationRenderer stampRenderer;

  /// The explicit Move/Resize state. Selection chrome that draws ON the page
  /// (bounding box, corner handles, rotate handle) is shown only while this
  /// is true, so a plain selection never decorates the document.
  final bool transformMode;

  /// Toggles transform mode from the contextual action bar.
  final VoidCallback? onToggleTransform;

  /// Bumped when an async image decode finishes, forcing a canvas repaint.
  final int canvasRevision;

  /// The PDF's own form fields, drawn above the page and below the marks.
  final Widget? formLayer;
  final void Function(Offset localPosition, Size canvasSize) onTapUp;
  final void Function(Offset localPosition, Size canvasSize) onPanStart;
  final void Function(Offset localPosition, Size canvasSize) onPanUpdate;
  final VoidCallback onPanEnd;
  final void Function(DetectedField field) onFieldTap;
  final void Function(OcrLine line) onEditLineTap;
  final void Function(TextAnnotation text) onEditText;
  final void Function(TextAnnotation text) onSelectText;
  final void Function(TextAnnotation text, DragUpdateDetails details, Size canvasSize) onMoveText;
  final void Function(Rect nextBounds) onResizeBounds;

  /// Drag lifecycle hooks so a whole move / resize becomes one undo step.
  final void Function(TextAnnotation text)? onMoveTextStart;
  final VoidCallback? onMoveTextEnd;
  final VoidCallback? onResizeStart;
  final VoidCallback? onResizeEnd;

  /// Rotation handle hooks (shown for images/stamps, which render rotation).
  final ValueChanged<double>? onRotate;
  final VoidCallback? onRotateStart;
  final VoidCallback? onRotateEnd;
  final VoidCallback onTextDecrease;
  final VoidCallback onTextIncrease;
  final VoidCallback onPickTextColor;
  final VoidCallback onEditShapeStyle;
  final VoidCallback onCopySelected;
  final VoidCallback onDuplicateSelected;
  final VoidCallback onBringToFront;
  final VoidCallback onSendToBack;
  final VoidCallback onDeleteSelected;
  final VoidCallback onDeselectSelected;
  final void Function(String how) onAlignMulti;
  final void Function(Axis axis) onDistributeMulti;
  final VoidCallback onDuplicateMulti;
  final VoidCallback onDeleteMulti;
  final VoidCallback onDeselectMulti;
  final void Function(StickyNoteAnnotation note)? onNoteTap;
  final void Function(StickyNoteAnnotation note)? onNoteDelete;

  /// Opens the properties of a selected form field the user added.
  final void Function(FormFieldAnnotation field)? onEditField;
  final IconData Function(FieldType type) resolveTypeIcon;

  const EditorCanvas({
    super.key,
    required this.bytes,
    required this.tool,
    required this.layer,
    required this.drawing,
    required this.shapeStart,
    required this.shapeEnd,
    required this.previewShapeType,
    required this.color,
    required this.stroke,
    required this.highlightPreview,
    this.securePreview = false,
    this.markupPreview = const [],
    this.markupKind,
    this.findRects = const [],
    this.activeFind = -1,
    this.wordSelection = const [],
    required this.showFields,
    required this.pageFields,
    required this.showEditLines,
    required this.editLines,
    required this.guideX,
    required this.guideY,
    required this.multi,
    required this.selMode,
    required this.marqueeStart,
    required this.marqueeEnd,
    required this.selected,
    required this.boundsOf,
    required this.imageRenderer,
    required this.stampRenderer,
    this.transformMode = false,
    this.onToggleTransform,
    this.canvasRevision = 0,
    this.formLayer,
    required this.onTapUp,
    required this.onPanStart,
    required this.onPanUpdate,
    required this.onPanEnd,
    required this.onFieldTap,
    required this.onEditLineTap,
    required this.onEditText,
    required this.onSelectText,
    required this.onMoveText,
    required this.onResizeBounds,
    this.onMoveTextStart,
    this.onMoveTextEnd,
    this.onResizeStart,
    this.onResizeEnd,
    this.onRotate,
    this.onRotateStart,
    this.onRotateEnd,
    required this.onTextDecrease,
    required this.onTextIncrease,
    required this.onPickTextColor,
    required this.onEditShapeStyle,
    required this.onCopySelected,
    required this.onDuplicateSelected,
    required this.onBringToFront,
    required this.onSendToBack,
    required this.onDeleteSelected,
    required this.onDeselectSelected,
    required this.onAlignMulti,
    required this.onDistributeMulti,
    required this.onDuplicateMulti,
    required this.onDeleteMulti,
    required this.onDeselectMulti,
    this.onNoteTap,
    this.onNoteDelete,
    this.onEditField,
    required this.resolveTypeIcon,
  });

  bool get _canDragText => tool == EditTool.pan || tool == EditTool.text;

  /// A text box laid out like the export lays it out (AnnotationTextLayout).
  static Widget _boxText(TextAnnotation t, Size size) {
    final box = AnnotationTextLayout.of(t, size);
    return ConstrainedBox(
      constraints: BoxConstraints(minWidth: box.minWidth, maxWidth: box.maxWidth),
      child: Text.rich(
        buildAnnotationTextSpan(t, box.style),
        textAlign: box.align,
        textDirection: box.direction,
        // Page text is sized to the page, not to the system font scale.
        textScaler: TextScaler.noScaling,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final size = Size(constraints.maxWidth, constraints.maxHeight);
        return GestureDetector(
          onTapUp: (d) => onTapUp(d.localPosition, size),
          onPanStart: (d) => onPanStart(d.localPosition, size),
          onPanUpdate: (d) => onPanUpdate(d.localPosition, size),
          onPanEnd: (_) => onPanEnd(),
          child: Stack(
            fit: StackFit.expand,
            children: [
              RepaintBoundary(
                child: Image.memory(
                  bytes,
                  fit: BoxFit.fill,
                  gaplessPlayback: true,
                  // Decode for the screen, plus headroom for a 2× pinch,
                  // instead of the full 2400px bitmap on every frame.
                  cacheWidth: (constraints.maxWidth *
                          MediaQuery.devicePixelRatioOf(context) *
                          2)
                      .round()
                      .clamp(64, 4096)
                      .toInt(),
                  filterQuality: FilterQuality.medium,
                ),
              ),
              if (formLayer != null) Positioned.fill(child: formLayer!),
              // The marks only paint. Without IgnorePointer a painter with no
              // hitTest counts as hit everywhere and would hide the form
              // fields from taps; the canvas gestures still arrive through
              // the page image.
              IgnorePointer(
                child: CustomPaint(
                  painter: EditorCanvasPainter(
                    layer.strokes,
                    layer.shapes,
                    layer.images,
                    layer.stamps,
                    imageRenderer,
                    stampRenderer,
                    drawing,
                    shapeStart,
                    shapeEnd,
                    previewShapeType,
                    color,
                    stroke,
                    highlightPreview,
                    securePreview: securePreview,
                    markups: layer.markups,
                    markupPreview: markupPreview,
                    markupKind: markupKind,
                    findRects: findRects,
                    activeFind: activeFind,
                    wordSelection: wordSelection,
                    revision: canvasRevision,
                  ),
                ),
              ),
              for (final f in layer.fields.where((f) => f.visible))
                Positioned(
                  left: f.pos.dx * size.width,
                  top: f.pos.dy * size.height,
                  child: FormFieldBox(field: f, page: size),
                ),
              ...layer.notes.where((n) => n.visible).map(
                    (note) {
                      final maxX = size.width > 28 ? size.width - 28 : 0.0;
                      final maxY = size.height > 28 ? size.height - 28 : 0.0;
                      return Positioned(
                        left: (note.pos.dx * size.width).clamp(0.0, maxX).toDouble(),
                        top: (note.pos.dy * size.height).clamp(0.0, maxY).toDouble(),
                        child: StickyNoteWidget(
                          note: note,
                          onTap: () => onNoteTap?.call(note),
                          onDelete: onNoteDelete == null ? null : () => onNoteDelete!(note),
                        ),
                      );
                    },
                  ),
              if (showFields) ...pageFields.map((f) {
                final palette = EditorPalette.of(context);
                final isCheckbox = f.type == FieldType.checkbox;
                final isRadio = f.type == FieldType.radio;
                final base = isCheckbox
                    ? palette.detectTeal
                    : isRadio
                        ? palette.detectViolet
                        : palette.detectIndigo;
                return Positioned(
                  left: f.rect.left * size.width,
                  top: f.rect.top * size.height,
                  child: GestureDetector(
                    onTap: () => onFieldTap(f),
                    child: Container(
                      constraints: const BoxConstraints(minWidth: 26, minHeight: 18),
                      width: isCheckbox || isRadio
                          ? (f.rect.width * size.width).clamp(18.0, 40.0)
                          : null,
                      height: (f.rect.height * size.height).clamp(18.0, 60.0),
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        color: base.withValues(alpha: 0.16),
                        border: Border.all(color: base.withValues(alpha: 0.55), width: 1.2),
                        borderRadius: isRadio ? BorderRadius.circular(100) : BorderRadius.circular(5),
                      ),
                      child: Icon(resolveTypeIcon(f.type), size: 14, color: base),
                    ),
                  ),
                );
              }),
              if (showEditLines)
                // A little room around the text, so the box does not touch it.
                ...editLines.map((line) => Positioned(
                      left: line.x * size.width - 3,
                      top: line.y * size.height - 2,
                      width: (line.w * size.width + 6).clamp(12.0, size.width),
                      height: (line.h * size.height + 4).clamp(14.0, size.height),
                      child: EditTextTarget(label: line.text, onTap: () => onEditLineTap(line)),
                    )),
              if (guideX != null)
                Positioned(
                  left: guideX! * size.width,
                  top: 0,
                  bottom: 0,
                  child: IgnorePointer(child: Container(width: 1, color: Colors.pinkAccent)),
                ),
              if (guideY != null)
                Positioned(
                  top: guideY! * size.height,
                  left: 0,
                  right: 0,
                  child: IgnorePointer(child: Container(height: 1, color: Colors.pinkAccent)),
                ),
              ...multi.map((a) {
                final palette = EditorPalette.of(context);
                final r = boundsOf(a);
                return Positioned(
                  left: r.left * size.width,
                  top: r.top * size.height,
                  width: (r.width * size.width).clamp(6.0, size.width),
                  height: (r.height * size.height).clamp(6.0, size.height),
                  child: IgnorePointer(
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: palette.selectionBorder, width: 1),
                        color: palette.selectionTint,
                      ),
                    ),
                  ),
                );
              }),
              if (selMode == 'marquee' && marqueeStart != null && marqueeEnd != null)
                Positioned.fromRect(
                  rect: Rect.fromPoints(
                    Offset(marqueeStart!.dx * size.width, marqueeStart!.dy * size.height),
                    Offset(marqueeEnd!.dx * size.width, marqueeEnd!.dy * size.height),
                  ),
                  child: IgnorePointer(
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: EditorPalette.of(context).selectionBorder),
                        color: EditorPalette.of(context).selectionTint,
                      ),
                    ),
                  ),
                ),
              // Hidden text is not drawn (export leaves it out too); locked
              // text stays visible but cannot be selected, edited or dragged.
              ...layer.texts.where((t) => t.visible).map((t) => Positioned(
                    // The 3 px padding below is the tap and selection margin;
                    // the text itself sits exactly at pos, as in the export.
                    left: t.pos.dx * size.width - 3,
                    top: t.pos.dy * size.height - 3,
                    child: GestureDetector(
                      onTap: () {
                        if (t.locked) return;
                        // One handler for both steps: the screen selects on the
                        // first tap and opens the editor on the second.
                        onSelectText(t);
                      },
                      onPanStart: _canDragText && !t.locked
                          ? (_) => onMoveTextStart?.call(t)
                          : null,
                      onPanUpdate: _canDragText && !t.locked ? (d) => onMoveText(t, d, size) : null,
                      onPanEnd: _canDragText && !t.locked ? (_) => onMoveTextEnd?.call() : null,
                      child: Container(
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          // Selection is a light wash, never a border.
                          color: selected == t
                              ? EditorPalette.of(context).selectionTint
                              : null,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Transform.rotate(
                          angle: -t.rotation,
                          child: _boxText(t, size),
                        ),
                      ),
                    ),
                  )),
              if (selected != null && transformMode) ...[
                EditorSelectionBox(size: size, bounds: boundsOf(selected!)),
                EditorScaleHandle(
                  size: size,
                  bounds: boundsOf(selected!),
                  bottomRight: false,
                  onResizeBounds: onResizeBounds,
                  onResizeStart: onResizeStart,
                  onResizeEnd: onResizeEnd,
                ),
                EditorScaleHandle(
                  size: size,
                  bounds: boundsOf(selected!),
                  bottomRight: true,
                  onResizeBounds: onResizeBounds,
                  onResizeStart: onResizeStart,
                  onResizeEnd: onResizeEnd,
                ),
                if (onRotate != null &&
                    (selected is TextAnnotation ||
                     selected is ImageAnnotation ||
                     selected is StampAnnotation))
                  EditorRotateHandle(
                    size: size,
                    bounds: boundsOf(selected!),
                    onRotate: onRotate!,
                    onRotateStart: onRotateStart,
                    onRotateEnd: onRotateEnd,
                  ),
              ],
              if (selected != null)
                EditorSelectionActionBar(
                  showTextActions: selected is TextAnnotation,
                  showShapeActions: selected is ShapeAnnotation,
                  onEditText: selected is TextAnnotation ? () => onEditText(selected! as TextAnnotation) : null,
                  onTextDecrease: selected is TextAnnotation ? onTextDecrease : null,
                  onTextIncrease: selected is TextAnnotation ? onTextIncrease : null,
                  onPickTextColor: selected is TextAnnotation ? onPickTextColor : null,
                  onEditShapeStyle: selected is ShapeAnnotation ? onEditShapeStyle : null,
                  onEditField: selected is FormFieldAnnotation && onEditField != null
                      ? () => onEditField!(selected! as FormFieldAnnotation)
                      : null,
                  transformMode: transformMode,
                  onToggleTransform: onToggleTransform,
                  onCopy: onCopySelected,
                  onDuplicate: onDuplicateSelected,
                  onBringToFront: onBringToFront,
                  onSendToBack: onSendToBack,
                  onDelete: onDeleteSelected,
                  onDeselect: onDeselectSelected,
                ),
              if (multi.isNotEmpty)
                EditorMultiSelectionActionBar(
                  count: multi.length,
                  onAlignLeft: () => onAlignMulti('left'),
                  onAlignCenter: () => onAlignMulti('hcenter'),
                  onAlignRight: () => onAlignMulti('right'),
                  onAlignTop: () => onAlignMulti('top'),
                  onAlignMiddle: () => onAlignMulti('vcenter'),
                  onAlignBottom: () => onAlignMulti('bottom'),
                  onDistributeH: () => onDistributeMulti(Axis.horizontal),
                  onDistributeV: () => onDistributeMulti(Axis.vertical),
                  onDuplicate: onDuplicateMulti,
                  onDelete: onDeleteMulti,
                  onDeselect: onDeselectMulti,
                ),
            ],
          ),
        );
      },
    );
  }
}
